local list =
{
    [xi.zone.KUFTAL_TUNNEL] =
    {
        { 'Robber Crab', 'I HAVE BEEN RENAMED!' },
        { 'Cave Worm', 'IMMA WORM!' },
    },
}
return list
