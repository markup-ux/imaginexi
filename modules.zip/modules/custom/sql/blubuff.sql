/* ============================================================
   ImagineXI: BLU All-Spell Stat Packs (global floors)
   - Ensures every BLU spell grants at least +10 to STR/DEX/VIT/AGI/INT/MND/CHR
   - Leaves higher existing values intact; raises negatives up to +10
   - SQL-only, reversible
   ============================================================ */

START TRANSACTION;

/* ---------- Backups (drop if re-running) ---------- */
DROP TABLE IF EXISTS backup_blue_spell_mods_allstats_ixi;
CREATE TABLE backup_blue_spell_mods_allstats_ixi AS
SELECT * FROM blue_spell_mods;  -- PK(spellId, modid) confirmed:contentReference[oaicite:2]{index=2}

/* ---------- Helper: distinct BLU spell ids ---------- */
/* blue_spell_list holds BLU spells and their info:contentReference[oaicite:3]{index=3} */

/* STR (modid=8) floor +10 for all spells */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 8 AS modid, 10 AS value
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* DEX (modid=9) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 9, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* VIT (modid=10) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 10, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* AGI (modid=11) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 11, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* INT (modid=12) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 12, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* MND (modid=13) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 13, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

/* CHR (modid=14) floor +10 */
INSERT INTO blue_spell_mods (spellId, modid, value)
SELECT DISTINCT bsl.spellid, 14, 10
FROM blue_spell_list bsl
ON DUPLICATE KEY UPDATE value = GREATEST(blue_spell_mods.value, VALUES(value));

COMMIT;

/* ===============================
   ROLLBACK
   ===============================
START TRANSACTION;
TRUNCATE TABLE blue_spell_mods;
INSERT INTO blue_spell_mods SELECT * FROM backup_blue_spell_mods_allstats_ixi;
COMMIT;
*/
/* ImagineXI: BLU Recast Relief — Level-1 Fast Cast +25% (SQL-only) */
START TRANSACTION;

DROP TABLE IF EXISTS backup_blue_traits_recast_ixi;
CREATE TABLE backup_blue_traits_recast_ixi AS
SELECT * FROM blue_traits;  -- structure & PK come from your file:contentReference[oaicite:1]{index=1}

/* Always-on Fast Cast: points_needed = 0
   Uses existing modifier 170 (Fast Cast) seen in your data:contentReference[oaicite:2]{index=2}.
   Category 91 is a neutral slot (same one we used earlier); this upserts safely. */
INSERT INTO blue_traits (trait_category, trait_points_needed, traitid, modifier, value)
VALUES (91, 0, 211, 170, 25)
ON DUPLICATE KEY UPDATE value = VALUES(value), traitid = VALUES(traitid);


COMMIT;

/* ROLLBACK:
START TRANSACTION;
TRUNCATE TABLE blue_traits;
INSERT INTO blue_traits SELECT * FROM backup_blue_traits_recast_ixi;
COMMIT;
*/
