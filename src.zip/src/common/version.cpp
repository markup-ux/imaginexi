#include "version.h"

const char* version::GetGitSha()
{
    return "feec03f55a-dirty";
}

const char* version::GetGitBranch()
{
    return "base";
}

const char* version::GetGitDate()
{
    return "Tue May 6 10:17:28 2025";
}

const char* version::GetGitCommitSubject()
{
    return "Merge pull request #7530 from Xaver-DaRed/more-cleanup";
}

const char* version::GetVersionString()
{
    return "base (feec03f55a-dirty)";
}
