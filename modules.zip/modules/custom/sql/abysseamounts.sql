UPDATE zone_settings
SET misc = misc | 0x0004
WHERE zoneid IN (15,45,132,215,216,217,218,253,254,255);

-- Enable mounts in all main cities
UPDATE zone_settings
SET misc = misc | 0x0004
WHERE zoneid IN (
    230,231,232,233,  -- San d’Oria
    234,235,236,237,  -- Bastok
    238,239,240,241,242,  -- Windurst
    243,244,245,246,  -- Jeuno
    48,50,            -- Aht Urhgan
    256,257,          -- Adoulin
    247,248,249,250,251,252  -- Rabao, Selbina, Mhaura, Kazham, Hall of the Gods, Norg
);