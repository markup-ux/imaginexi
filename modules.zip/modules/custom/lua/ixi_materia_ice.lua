-- modules/custom/materia/ixi_materia_ice.lua
-- Imagine XI: Ice Materia (INT) – craft via Ice Crystal, levels up from EXP/Conquest

local M = {}

------------------------------------------------------------
-- CONFIG (🔧 set these to your DB ids / preferences)
------------------------------------------------------------
local CONFIG = {
    -- Your DB id for the *Ice Crystal* that opens the synthesis UI
    ICE_CRYSTAL_ID = 4097,   -- << REQUIRED: set to your "Ice Crystal" itemId

    -- Your DB id for the Ice Materia item itself.
    -- If you want it to *look* like an Ice Bead, just reuse the Ice Bead's item row / DAT.
    ICE_MATERIA_ITEM_ID = 1300, -- << REQUIRED: set to your "Ice Materia" (or Ice Bead) itemId

    -- Tag we write on augmented gear so we can detect it on-equip.
    -- We use xi.mod.NULL = 5002 as our “Ice Materia socket” marker (unique value).
    ICE_TAG_VALUE = 5002,

    -- Per-level INT granted by Ice Materia (applied per equipped tagged piece)
    INT_BY_LEVEL = { [0]=0, [1]=2, [2]=4, [3]=6, [4]=8, [5]=10 },

    -- Progression curve: total "Materia XP" needed to reach level N.
    -- (We accumulate from EXP + optional CP)
    -- Example: fast early levels, longer end.
    XP_THRESHOLDS = { [1]=1000, [2]=5000, [3]=25000, [4]=75000, [5]=175000 },

    -- How Materia XP is earned
    EXP_TO_MATXP_RATIO = 1.0,   -- 1 EXP -> 1 Materia XP
    CP_TO_MATXP_RATIO  = 10.0,  -- 1 Conquest Point -> 10 Materia XP (optional; set 0 to disable)

    -- Safety / balance caps
    MAX_SOCKETS_COUNTED = 8,    -- max tagged pieces counted toward INT (to avoid silly stacking)
    EFFECT_DURATION_SEC = 600,  -- 10m refresh window for status/mod upkeep
}

-- CharVars we use to persist global Ice Materia progress
local VARS = {
    XP     = "IXI_ICE_MAT_XP",     -- cumulative Materia XP (from EXP/CP)
    LEVEL  = "IXI_ICE_MAT_LEVEL",  -- 0..5
    APPLIED_INT = "IXI_ICE_MAT_APPLIED_INT", -- last applied total INT to remove cleanly on refresh
}

------------------------------------------------------------
-- INTERNAL UTILS
------------------------------------------------------------
local function clamp(x, lo, hi) if x < lo then return lo elseif x > hi then return hi else return x end end

local function computeLevelFromXP(xp)
    local lvl = 0
    for L = 1, 5 do
        if xp >= CONFIG.XP_THRESHOLDS[L] then lvl = L else break end
    end
    return lvl
end

-- Count how many equipped items have our Ice tag
local function countIceSocketsEquipped(player)
    local count = 0
    for slot = xi.slot.MAIN, xi.slot.BACK do
        local aug = player.getAugments and player:getAugments(slot) or nil
        if aug then
            for _, p in ipairs(aug) do
                local modId, val = p[1], p[2]
                if modId == xi.mod.NULL and val == CONFIG.ICE_TAG_VALUE then
                    count = count + 1
                    break
                end
            end
        end
    end
    return clamp(count, 0, CONFIG.MAX_SOCKETS_COUNTED)
end

-- Remove previously applied INT so we don't double stack
local function clearApplied(player)
    local last = player:getLocalVar(VARS.APPLIED_INT) or 0
    if last ~= 0 then
        player:delMod(xi.mod.INT, last)
        player:setLocalVar(VARS.APPLIED_INT, 0)
    end
end

-- Apply per-equip INT based on current level and # of sockets equipped
local function applyCurrent(player)
    clearApplied(player)

    local xp   = player:getCharVar(VARS.XP)
    local lvl  = computeLevelFromXP(xp)
    player:setCharVar(VARS.LEVEL, lvl)

    local perPiece = CONFIG.INT_BY_LEVEL[lvl] or 0
    local pieces   = countIceSocketsEquipped(player)
    local totalInt = perPiece * pieces

    if totalInt ~= 0 then
        player:addMod(xi.mod.INT, totalInt)
        player:setLocalVar(VARS.APPLIED_INT, totalInt)
    end

    -- tiny, harmless status to give you a visual queue if you like (comment out if not wanted)
    -- player:delStatusEffectSilent(xi.effect.ENBLIZZARD)
    -- if pieces > 0 and lvl > 0 then
    --     player:addStatusEffect(xi.effect.ENBLIZZARD, 1, 0, CONFIG.EFFECT_DURATION_SEC)
    -- end
end

------------------------------------------------------------
-- PUBLIC: call on login/zone/equip-change to re-eval bonuses
------------------------------------------------------------
function M.refresh(player)
    if not player then return end
    applyCurrent(player)
end

------------------------------------------------------------
-- PUBLIC: call when player gains EXP
------------------------------------------------------------
function M.onGainExp(player, amount)
    if not player or not amount or amount <= 0 then return end
    local add = math.floor(amount * CONFIG.EXP_TO_MATXP_RATIO)
    if add <= 0 then return end

    local cur = player:getCharVar(VARS.XP)
    player:setCharVar(VARS.XP, cur + add)
    applyCurrent(player)
end

------------------------------------------------------------
-- PUBLIC: call when player gains Conquest Points (optional)
------------------------------------------------------------
function M.onGainConquest(player, cpAmount)
    if not player or not cpAmount or cpAmount <= 0 then return end
    if CONFIG.CP_TO_MATXP_RATIO <= 0 then return end

    local add = math.floor(cpAmount * CONFIG.CP_TO_MATXP_RATIO)
    if add <= 0 then return end

    local cur = player:getCharVar(VARS.XP)
    player:setCharVar(VARS.XP, cur + add)
    applyCurrent(player)
end

------------------------------------------------------------
-- SYNTHESIS INTERCEPT (Ice Crystal recipe: 1 gear + 1 Ice Materia)
------------------------------------------------------------
local function isArmorEquip(itemId)
    local it = GetItemByID and GetItemByID(itemId)
    if not it then return false end
    local slots = it:getSlots() or 0
    if slots == 0 then return false end
    -- exclude weapons for v1 (you can allow later)
    if bit.band(slots, xi.slot.MAIN)   ~= 0 then return false end
    if bit.band(slots, xi.slot.SUB)    ~= 0 then return false end
    if bit.band(slots, xi.slot.RANGED) ~= 0 then return false end
    if bit.band(slots, xi.slot.AMMO)   ~= 0 then return false end
    return true
end

local function addItemWithAug(player, itemId, augPairs)
    -- Most forks: addItem(id, qty, keepAugments, { {modId,val}, ... })
    player:addItem(itemId, 1, true, augPairs)
end

-- Call this from your synth-success path BEFORE default result is awarded.
-- Returns true if we handled (consumed materials & returned augmented original gear).
function M.tryHandleIceMateriaSynthesis(player, crystalId, ingredientIds)
    if not player or not ingredientIds or CONFIG.ICE_CRYSTAL_ID == 0 or CONFIG.ICE_MATERIA_ITEM_ID == 0 then
        return false
    end
    if crystalId ~= CONFIG.ICE_CRYSTAL_ID then
        return false
    end

    -- Find exactly 1 armor + 1 Ice Materia
    local equipId, hadMateria = nil, false
    local meaningful = 0

    for _, id in ipairs(ingredientIds) do
        if id and id ~= 0 then
            if id == CONFIG.ICE_MATERIA_ITEM_ID then
                if hadMateria then return false end
                hadMateria = true
                meaningful = meaningful + 1
            elseif isArmorEquip(id) then
                if equipId then return false end
                equipId = id
                meaningful = meaningful + 1
            end
        end
    end

    if not hadMateria or not equipId or meaningful ~= 2 then
        return false
    end

    -- Build augments: write the tag marker so refresh() can detect on-equip
    local augPairs = {
        { xi.mod.NULL, CONFIG.ICE_TAG_VALUE },
        { xi.mod.MACC, 0 }, -- harmless filler; some forks expect at least 2 aug pairs
    }

    player:tradeComplete()
    addItemWithAug(player, equipId, augPairs)

    local zt = zones[player:getZoneID()] and zones[player:getZoneID()].text
    if zt and zt.ITEM_OBTAINED then
        player:messageSpecial(zt.ITEM_OBTAINED, equipId)
    else
        player:PrintToPlayer("Ice Materia fused into gear.")
    end

    -- Immediate recompute (in case they crafted while wearing that gear)
    applyCurrent(player)
    return true
end

return M
