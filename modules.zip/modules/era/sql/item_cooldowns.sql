UPDATE `item_usable` SET reuseDelay = 259200 WHERE `name` = "moogle_cap"; -- 72 hours (in seconds)
UPDATE `item_usable` SET reuseDelay = 259200 WHERE `name` = "nomad_cap";  -- 72 hours (in seconds)
