START TRANSACTION;

-- Purge existing mods for RUN/GEO AF1 to prevent leftover level 99 stats
DELETE FROM item_mods WHERE itemId IN (
    27787, 27927, 28067, 28207, 28347,  -- RUN: Bandeau, Coat, Mitons, Trousers, Bottes
    27786, 27926, 28066, 28206, 28346   -- GEO: Galero, Tunic, Mitaines, Pants, Sandals
);


-- Runeist's Bandeau
INSERT INTO item_mods (itemId, modId, value) VALUES
(27787,1,20),
(27787,10,4),
(27787,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Runeist's Coat
INSERT INTO item_mods (itemId, modId, value) VALUES
(27927,1,45),
(27927,2,40),
(27927,27,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Runeist's Mitons
INSERT INTO item_mods (itemId, modId, value) VALUES
(28067,1,18),
(28067,8,4),
(28067,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Runeist's Trousers
INSERT INTO item_mods (itemId, modId, value) VALUES
(28207,1,32),
(28207,10,6),
(28207,29,4)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Runeist's Bottes
INSERT INTO item_mods (itemId, modId, value) VALUES
(28347,1,16),
(28347,2,25),
(28347,989,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Geomancy Galero
INSERT INTO item_mods (itemId, modId, value) VALUES
(27786,1,18),
(27786,12,6),
(27786,30,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Geomancy Tunic
INSERT INTO item_mods (itemId, modId, value) VALUES
(27926,1,36),
(27926,2,20),
(27926,5,30),
(27926,28,10),
(27926,123,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Geomancy Mitaines
INSERT INTO item_mods (itemId, modId, value) VALUES
(28066,1,16),
(28066,12,5),
(28066,30,8),
(28066,124,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Geomancy Pants
INSERT INTO item_mods (itemId, modId, value) VALUES
(28206,1,28),
(28206,12,8),
(28206,28,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Geomancy Sandals
INSERT INTO item_mods (itemId, modId, value) VALUES
(28346,1,12),
(28346,12,4),
(28346,30,6),
(28346,123,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Corsair's Tricorne
INSERT INTO item_mods (itemId, modId, value) VALUES
(15266,26,10),
(15266,11,4),
(15266,365,300)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Corsair's Frac
INSERT INTO item_mods (itemId, modId, value) VALUES
(14522,9,8),
(14522,24,15),
(14522,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Corsair's Gants
INSERT INTO item_mods (itemId, modId, value) VALUES
(14929,11,6),
(14929,26,10),
(14929,359,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Corsair's Culottes
INSERT INTO item_mods (itemId, modId, value) VALUES
(15601,11,8),
(15601,24,12),
(15601,73,4)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Corsair's Bottes
INSERT INTO item_mods (itemId, modId, value) VALUES
(15685,26,10),
(15685,9,4),
(15685,365,200)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Dancer's Tiara
INSERT INTO item_mods (itemId, modId, value) VALUES
(16139,9,6),
(16139,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Dancer's Casaque
INSERT INTO item_mods (itemId, modId, value) VALUES
(14579,8,6),
(14579,25,10),
(14579,23,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Dancer's Bangles
INSERT INTO item_mods (itemId, modId, value) VALUES
(15003,9,8),
(15003,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Dancer's Tights
INSERT INTO item_mods (itemId, modId, value) VALUES
(15660,9,6),
(15660,25,10),
(15660,384,300)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Dancer's Toe Shoes
INSERT INTO item_mods (itemId, modId, value) VALUES
(15747,11,6),
(15747,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Fighter's Mask
INSERT INTO item_mods (itemId, modId, value) VALUES
(12511,8,6),
(12511,9,4),
(12511,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Fighter's Lorica
INSERT INTO item_mods (itemId, modId, value) VALUES
(12638,8,6),
(12638,25,10),
(12638,23,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Fighter's Mufflers
INSERT INTO item_mods (itemId, modId, value) VALUES
(13961,9,6),
(13961,288,2),
(13961,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Fighter's Cuisses
INSERT INTO item_mods (itemId, modId, value) VALUES
(14214,8,6),
(14214,25,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Fighter's Calligae
INSERT INTO item_mods (itemId, modId, value) VALUES
(14089,9,5),
(14089,23,8),
(14089,73,2)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Temple Crown
INSERT INTO item_mods (itemId, modId, value) VALUES
(12512,10,5),
(12512,292,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Temple Cyclas
INSERT INTO item_mods (itemId, modId, value) VALUES
(12639,8,6),
(12639,25,10),
(12639,23,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Temple Gloves
INSERT INTO item_mods (itemId, modId, value) VALUES
(13962,9,6),
(13962,173,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Temple Hose
INSERT INTO item_mods (itemId, modId, value) VALUES
(14215,10,6),
(14215,291,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Temple Gaiters
INSERT INTO item_mods (itemId, modId, value) VALUES
(14090,9,5),
(14090,25,8),
(14090,73,2)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Healer's Cap
INSERT INTO item_mods (itemId, modId, value) VALUES
(13855,13,6),
(13855,374,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Healer's Mitts
INSERT INTO item_mods (itemId, modId, value) VALUES
(13963,13,5),
(13963,30,6)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Healer's Duckbills
INSERT INTO item_mods (itemId, modId, value) VALUES
(14091,170,3),
(14091,27,-3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Wizard's Petasos
INSERT INTO item_mods (itemId, modId, value) VALUES
(13856,12,6),
(13856,30,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Wizard's Coat
INSERT INTO item_mods (itemId, modId, value) VALUES
(12641,5,30),
(12641,28,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Wizard's Gloves
INSERT INTO item_mods (itemId, modId, value) VALUES
(13964,12,5),
(13964,170,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Wizard's Tonban
INSERT INTO item_mods (itemId, modId, value) VALUES
(14217,30,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Wizard's Sabots
INSERT INTO item_mods (itemId, modId, value) VALUES
(14092,12,4),
(14092,28,6)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Warlock's Chapeau
INSERT INTO item_mods (itemId, modId, value) VALUES
(12513,12,5),
(12513,30,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Warlock's Tabard
INSERT INTO item_mods (itemId, modId, value) VALUES
(12642,13,5),
(12642,170,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Warlock's Gloves
INSERT INTO item_mods (itemId, modId, value) VALUES
(13965,30,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Warlock's Tights
INSERT INTO item_mods (itemId, modId, value) VALUES
(14218,890,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Warlock's Boots
INSERT INTO item_mods (itemId, modId, value) VALUES
(14093,27,-3),
(14093,170,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Rogue's Bonnet
INSERT INTO item_mods (itemId, modId, value) VALUES
(12514,9,6),
(12514,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Rogue's Vest
INSERT INTO item_mods (itemId, modId, value) VALUES
(12643,11,6),
(12643,25,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Rogue's Armlets
INSERT INTO item_mods (itemId, modId, value) VALUES
(13966,259,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Rogue's Culottes
INSERT INTO item_mods (itemId, modId, value) VALUES
(14219,9,6),
(14219,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Rogue's Poulaines
INSERT INTO item_mods (itemId, modId, value) VALUES
(14094,302,2)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Gallant Coronet
INSERT INTO item_mods (itemId, modId, value) VALUES
(12515,10,6),
(12515,27,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Gallant Surcoat
INSERT INTO item_mods (itemId, modId, value) VALUES
(12644,1,45),
(12644,2,50),
(12644,27,4)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Gallant Gauntlets
INSERT INTO item_mods (itemId, modId, value) VALUES
(13967,10,5),
(13967,170,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Gallant Breeches
INSERT INTO item_mods (itemId, modId, value) VALUES
(14220,10,6),
(14220,29,4)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Gallant Leggings
INSERT INTO item_mods (itemId, modId, value) VALUES
(14095,2,30),
(14095,27,2)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Chaos Burgeonet
INSERT INTO item_mods (itemId, modId, value) VALUES
(12516,8,6),
(12516,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Chaos Cuirass
INSERT INTO item_mods (itemId, modId, value) VALUES
(12645,8,6),
(12645,25,10),
(12645,23,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Chaos Gauntlets
INSERT INTO item_mods (itemId, modId, value) VALUES
(13968,9,6),
(13968,288,2)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Chaos Flanchard
INSERT INTO item_mods (itemId, modId, value) VALUES
(14221,8,6),
(14221,25,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Chaos Sollerets
INSERT INTO item_mods (itemId, modId, value) VALUES
(14096,73,3),
(14096,23,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Beast Helm
INSERT INTO item_mods (itemId, modId, value) VALUES
(12517,8,5),
(12517,991,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Beast Jackcoat
INSERT INTO item_mods (itemId, modId, value) VALUES
(12646,23,10),
(12646,990,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Beast Gloves
INSERT INTO item_mods (itemId, modId, value) VALUES
(13969,9,6),
(13969,991,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Beast Trousers
INSERT INTO item_mods (itemId, modId, value) VALUES
(14222,8,6),
(14222,993,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Beast Gaiters
INSERT INTO item_mods (itemId, modId, value) VALUES
(14097,73,2),
(14097,995,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Choral Roundlet
INSERT INTO item_mods (itemId, modId, value) VALUES
(13857,14,6),
(13857,30,6)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Choral Cuffs
INSERT INTO item_mods (itemId, modId, value) VALUES
(13970,30,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Choral Cannions
INSERT INTO item_mods (itemId, modId, value) VALUES
(14223,454,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Choral Slippers
INSERT INTO item_mods (itemId, modId, value) VALUES
(14098,170,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Hunter's Beret
INSERT INTO item_mods (itemId, modId, value) VALUES
(12518,11,6),
(12518,26,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Hunter's Jerkin
INSERT INTO item_mods (itemId, modId, value) VALUES
(12648,24,15),
(12648,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Hunter's Bracers
INSERT INTO item_mods (itemId, modId, value) VALUES
(13971,11,6),
(13971,26,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Hunter's Braccae
INSERT INTO item_mods (itemId, modId, value) VALUES
(14224,24,12),
(14224,73,4)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Hunter's Socks
INSERT INTO item_mods (itemId, modId, value) VALUES
(14099,26,10),
(14099,365,300)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Myochin Kabuto
INSERT INTO item_mods (itemId, modId, value) VALUES
(13868,8,6),
(13868,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Myochin Domaru
INSERT INTO item_mods (itemId, modId, value) VALUES
(13781,8,6),
(13781,25,10),
(13781,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Myochin Kote
INSERT INTO item_mods (itemId, modId, value) VALUES
(13972,9,6),
(13972,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Myochin Haidate
INSERT INTO item_mods (itemId, modId, value) VALUES
(14225,25,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Ninja Hatsuburi
INSERT INTO item_mods (itemId, modId, value) VALUES
(13869,9,6),
(13869,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Ninja Chainmail
INSERT INTO item_mods (itemId, modId, value) VALUES
(13782,11,6),
(13782,68,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Ninja Tekko
INSERT INTO item_mods (itemId, modId, value) VALUES
(13973,259,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Ninja Hakama
INSERT INTO item_mods (itemId, modId, value) VALUES
(14226,25,10),
(14226,289,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Ninja Kyahan
INSERT INTO item_mods (itemId, modId, value) VALUES
(14101,384,300)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Drachen Armet
INSERT INTO item_mods (itemId, modId, value) VALUES
(12519,8,6),
(12519,25,8)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Drachen Mail
INSERT INTO item_mods (itemId, modId, value) VALUES
(12649,8,6),
(12649,23,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Drachen Brais
INSERT INTO item_mods (itemId, modId, value) VALUES
(14227,25,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Drachen Greaves
INSERT INTO item_mods (itemId, modId, value) VALUES
(14102,361,20)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Evoker's Horn
INSERT INTO item_mods (itemId, modId, value) VALUES
(12520,5,30),
(12520,296,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Evoker's Doublet
INSERT INTO item_mods (itemId, modId, value) VALUES
(12650,992,5),
(12650,126,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Evoker's Bracers
INSERT INTO item_mods (itemId, modId, value) VALUES
(13975,993,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Evoker's Spats
INSERT INTO item_mods (itemId, modId, value) VALUES
(14228,357,-5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Evoker's Pigaches
INSERT INTO item_mods (itemId, modId, value) VALUES
(14103,991,10),
(14103,993,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Magus Keffiyeh
INSERT INTO item_mods (itemId, modId, value) VALUES
(15265,9,6),
(15265,25,8),
(15265,122,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Magus Jubbah
INSERT INTO item_mods (itemId, modId, value) VALUES
(14521,8,5),
(14521,122,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Magus Bazubands
INSERT INTO item_mods (itemId, modId, value) VALUES
(14928,9,6),
(14928,73,3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Magus Shalwar
INSERT INTO item_mods (itemId, modId, value) VALUES
(15600,28,8),
(15600,122,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Magus Charuqs
INSERT INTO item_mods (itemId, modId, value) VALUES
(15684,170,5),
(15684,25,6)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Scholar's Gown
INSERT INTO item_mods (itemId, modId, value) VALUES
(14580,5,30),
(14580,28,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Scholar's Bracers
INSERT INTO item_mods (itemId, modId, value) VALUES
(15004,13,5),
(15004,374,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Scholar's Pants
INSERT INTO item_mods (itemId, modId, value) VALUES
(16311,890,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);

-- Scholar's Loafers
INSERT INTO item_mods (itemId, modId, value) VALUES
(15748,170,3),
(15748,27,-3)
ON DUPLICATE KEY UPDATE value=VALUES(value);

COMMIT;

-- PUP items (manually added IDs)
-- Puppetry Taj
INSERT INTO item_mods (itemId, modId, value) VALUES
(15267,25,8),
(15267,9,4),
(15267,73,2),
(15267,991,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);
-- Puppetry Tobe
INSERT INTO item_mods (itemId, modId, value) VALUES
(14523,25,10),
(14523,23,10),
(14523,8,5),
(14523,990,5),
(14523,993,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);
-- Puppetry Dastanas
INSERT INTO item_mods (itemId, modId, value) VALUES
(14930,9,6),
(14930,25,8),
(14930,73,3),
(14930,289,5),
(14930,993,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);
-- Puppetry Churidars
INSERT INTO item_mods (itemId, modId, value) VALUES
(15602,8,8),
(15602,23,10),
(15602,73,2),
(15602,995,10)
ON DUPLICATE KEY UPDATE value=VALUES(value);
-- Puppetry Babouches
INSERT INTO item_mods (itemId, modId, value) VALUES
(15686,25,8),
(15686,9,4),
(15686,991,5)
ON DUPLICATE KEY UPDATE value=VALUES(value);

COMMIT;