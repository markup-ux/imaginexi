-----------------------------------
-- CP & Sparks Exchange (Autospawn next to Signet/Conquest guards)
--
-- What it does:
--   • Auto-spawns a single “Exchange” NPC beside every Signet/Conquest guard on zone load.
--   • Players pick which currency to spend: Conquest Points (CP) or Sparks of Eminence (Sparks).
--   • Converts CP/Sparks into endgame currencies: Dynamis (singles/100s), Alexandrite, Cruor,
--     Heavy Metal Plate, Riftdross/Riftcinder, Nyzul Tokens, Therion Ichor.
--   • Paged quantity menus up to 5000 with a MAX option that asks “Are you sure?” before spending.
--   • Safer flow: pre-checks inventory space and refunds currency on unexpected failures.
--
-- Notes:
--   • Sparks prices currently mirror CP prices. Adjust in RATES[].cost.sp as desired.
-----------------------------------

package.path = package.path .. ';./?.lua' .. ';./?/init.lua'

require('modules/module_utils')
require('scripts/globals/conquest')   -- xi.conquest.*
require('scripts/enum/item')          -- xi.item.*

local m = Module:new('cp_exchange_autospawn')

-- ======================
-- Exchange rates (per 1 output unit)
-- Use cost.cp for CP price; cost.sp for Sparks price
-- ======================
local RATES = {
    -- Dynamis (singles)
    { id='byne',    label='Byne Bill',          type='item',     itemId=xi.item.ONE_BYNE_BILL,         cost={ cp=50,   sp=50 } },
    { id='obronze', label='O. Bronzepiece',     type='item',     itemId=xi.item.ORDELLE_BRONZEPIECE,   cost={ cp=50,   sp=50 } },
    { id='twhite',  label='T. Whiteshell',      type='item',     itemId=xi.item.TUKUKU_WHITESHELL,     cost={ cp=50,   sp=50 } },
    -- Dynamis (100s)
    { id='100byne', label='100 Byne Bill',      type='item',     itemId=xi.item.ONE_HUNDRED_BYNE_BILL, cost={ cp=5000, sp=5000 } },
    { id='msilver', label='M. Silverpiece',     type='item',     itemId=xi.item.MONTIONT_SILVERPIECE,  cost={ cp=5000, sp=5000 } },
    { id='ljade',   label='L. Jadeshell',       type='item',     itemId=xi.item.LUNGO_NANGO_JADESHELL, cost={ cp=5000, sp=5000 } },
    -- Alexandrite
    { id='alex',    label='Alexandrite',        type='item',     itemId=xi.item.ALEXANDRITE,           cost={ cp=60,   sp=60 } },
    -- Cruor (currency)
    { id='cruor',   label='Cruor',              type='currency', key='cruor',                          cost={ cp=1,    sp=1 },   out_mult=1 },
    -- Empyrean + misc
    { id='hmp',     label='Heavy Metal Plate',  type='item',     itemId=xi.item.PLATE_OF_HEAVY_METAL,  cost={ cp=1000, sp=1000 } },
    { id='dross',   label='Riftdross',          type='item',     itemId=xi.item.CLUMP_OF_RIFTDROSS,    cost={ cp=7500, sp=7500 } },
    { id='cinder',  label='Riftcinder',         type='item',     itemId=xi.item.PINCH_OF_RIFTCINDER,   cost={ cp=10000,sp=10000 } },
    { id='nyzul',   label='Nyzul Tokens',       type='currency', key='nyzul_isle_tokens',              cost={ cp=1,    sp=1 },   out_mult=1 },
    { id='ichor',   label='Therion Ichor',      type='currency', key='therion_ichor',                  cost={ cp=10,   sp=10 },  out_mult=1 },
}

-- Quantity choices up to 5000 (paged to fit client caps)
local UNITS_CHOICES  = { 1, 10, 50, 99, 100, 250, 500, 1000, 2500, 5000 }
local UNITS_PER_PAGE = 4   -- Prev + 4 nums + MAX + Next + Back = <= 8 entries

-- ======================
-- Menu state + helpers
-- ======================
local menu        = { title = 'Exchange', options = {} }
local rootTender  = {} -- first screen: choose CP or Sparks
local currentNpc  = nil

-- Page factories (depend on tender)
local page1, page2, page3

local function normalizeTender(t)
    if t == 'sp' or t == 'sparks' then return 'sp' end
    return 'cp'
end

local function delaySendMenu(player)
    player:timer(50, function(p) p:customMenu(menu) end)
end

local function printLine(p, npc, text)
    local name = (npc and npc.getPacketName and npc:getPacketName()) or 'Exchange'
    p:printToPlayer(text, 0, name)
end

-- --------- Currency accessors (CP & Sparks) ----------
local function getPoints(p, tender)
    tender = normalizeTender(tender)
    if tender == 'cp' then
        if p.getCP then return p:getCP() or 0 end
        if p.getCurrency then return p:getCurrency('conquest_points') or 0 end
        return 0
    else
        -- Your fork uses singular 'spark_of_eminence'; keep fallbacks for safety. (DB column shown in your schema.)
        -- See: char_points.sql -> `spark_of_eminence` column.  (citation outside code)
        if p.getCurrency then
            return p:getCurrency('spark_of_eminence')
                or p:getCurrency('sparks_of_eminence') -- some forks
                or p:getCurrency('sparks')             -- some forks
                or p:getCurrency('spark_points')       -- some forks
                or 0
        end
        return 0
    end
end

local function takePoints(p, tender, amount)
    tender = normalizeTender(tender)
    if amount <= 0 then return end
    if tender == 'cp' then
        if p.delCP       then p:delCP(amount); return end
        if p.delCurrency then p:delCurrency('conquest_points', amount); return end
    else
        if p.delCurrency then p:delCurrency('spark_of_eminence', amount); return end
    end
end

local function refundPoints(p, tender, amount)
    tender = normalizeTender(tender)
    if amount <= 0 then return end
    if tender == 'cp' then
        if p.addCP       then p:addCP(amount)
        elseif p.addCurrency then p:addCurrency('conquest_points', amount) end
    else
        if p.addCurrency then p:addCurrency('spark_of_eminence', amount) end
    end
end

local function rateById(id)
    for _, r in ipairs(RATES) do if r.id == id then return r end end
end

local function unitCost(r, tender)
    tender = normalizeTender(tender)
    return (r.cost and r.cost[tender]) or 0
end

local function formatRateLine(r, tender)
    local per = unitCost(r, tender)
    if r.type == 'currency' then
        return string.format('- %s: %d %s -> %d %s', r.label, per, (tender=='cp' and 'CP' or 'Sparks'), (r.out_mult or 1), r.label)
    else
        return string.format('- %s: %d %s -> 1 %s', r.label, per, (tender=='cp' and 'CP' or 'Sparks'), r.label)
    end
end

local function canAfford(p, r, tender, units)
    local need = unitCost(r, tender) * units
    return getPoints(p, tender) >= need, need
end

local function hasSpaceFor(p, itemId, units)
    local stacksNeeded = math.ceil(units / 99)
    local free = p:getFreeSlotsCount() or 0
    return free >= stacksNeeded, stacksNeeded, free
end

local function giveOut(p, r, units)
    if r.type == 'currency' then
        local total = units * (r.out_mult or 1)
        p:addCurrency(r.key, total)
        return total
    else
        if (p:getFreeSlotsCount() or 0) <= 0 then
            return false, 'You need at least 1 free inventory slot.'
        end
        local remain = units
        while remain > 0 do
            local give = math.min(remain, 99)
            if not p:addItem(r.itemId, give) then
                return false, 'Inventory full or item could not be added.'
            end
            remain = remain - give
        end
        return true
    end
end

-- Forward decls
local showUnitsPage
local showRootTender

-- Confirm screen for MAX
local function showConfirmMax(player, rate, pageIndex, backPage, tender)
    tender = normalizeTender(tender)
    local per = unitCost(rate, tender)
    local pts = getPoints(player, tender)
    local u   = math.floor(pts / math.max(1, per))
    if rate.type == 'item' then u = math.min(u, 12 * 99) end

    if u <= 0 then
        printLine(player, currentNpc, 'You cannot afford any units right now.')
        return
    end

    if rate.type == 'item' then
        local ok, needSlots, free = hasSpaceFor(player, rate.itemId, u)
        if not ok then
            printLine(player, currentNpc,
                ('Not enough inventory space: need %d empty slot(s), you have %d. No %s spent.'):format(needSlots, free, (tender=='cp' and 'CP' or 'Sparks')))
            return
        end
    end

    local need = per * u
    local outDesc, outCount
    if rate.type == 'currency' then
        outCount = (rate.out_mult or 1) * u
        outDesc  = string.format('%d %s', outCount, rate.label)
    else
        outCount = u
        outDesc  = string.format('%d %s', u, rate.label)
    end

    local opts = {}
    local function push(lbl, fn) table.insert(opts, { lbl, fn }) end

    push(('Yes - spend %d %s for %s'):format(need, (tender=='cp' and 'CP' or 'Sparks'), outDesc), function(pp)
        takePoints(pp, tender, need)
        local ok, err = giveOut(pp, rate, u)
        if ok == false then
            refundPoints(pp, tender, need)
            printLine(pp, currentNpc, ('Conversion failed: %s. %s refunded: %d.'):format(err or 'inventory/cap issue', (tender=='cp' and 'CP' or 'Sparks'), need))
        else
            printLine(pp, currentNpc, ('Converted %d %s -> %d %s.'):format(need, (tender=='cp' and 'CP' or 'Sparks'), (rate.type=='currency' and outCount or u), rate.label))
        end
        showUnitsPage(pp, rate, pageIndex, backPage, tender)
    end)

    push('No - go back', function(pp)
        showUnitsPage(pp, rate, pageIndex, backPage, tender)
    end)

    menu.options = opts
    delaySendMenu(player)
end

-- Quantity page (paged)
showUnitsPage = function(player, rate, pageIndex, backPage, tender)
    tender = normalizeTender(tender)
    printLine(player, currentNpc, formatRateLine(rate, tender))

    local opts = {}
    local function push(lbl, fn) table.insert(opts, { lbl, fn }) end

    local start = (pageIndex - 1) * UNITS_PER_PAGE + 1
    local stop  = math.min(#UNITS_CHOICES, start + UNITS_PER_PAGE - 1)
    local hasPrev = start > 1
    local hasNext = stop  < #UNITS_CHOICES

    if hasPrev then push('<< Prev', function(pp) showUnitsPage(pp, rate, pageIndex - 1, backPage, tender) end) end

    for i = start, stop do
        local u = UNITS_CHOICES[i]
        push(('Buy x%d'):format(u), function(pp)
            local ok, need = canAfford(pp, rate, tender, u)
            if not ok then
                printLine(pp, currentNpc, ('Not enough %s. Need %d %s for x%d.'):format((tender=='cp' and 'CP' or 'Sparks'), need, (tender=='cp' and 'CP' or 'Sparks'), u))
                return
            end

            if rate.type == 'item' then
                local spaceOK, slotsNeeded, free = hasSpaceFor(pp, rate.itemId, u)
                if not spaceOK then
                    printLine(pp, currentNpc, ('Not enough inventory space: need %d empty slot(s), you have %d. No %s spent.'):format(slotsNeeded, free, (tender=='cp' and 'CP' or 'Sparks')))
                    return
                end
            end

            takePoints(pp, tender, need)
            local out, err = giveOut(pp, rate, u)
            if out == false then
                refundPoints(pp, tender, need)
                printLine(pp, currentNpc, ('Conversion failed: %s. %s refunded: %d.'):format(err or 'inventory/cap issue', (tender=='cp' and 'CP' or 'Sparks'), need))
                return
            end

            if rate.type == 'currency' then
                printLine(pp, currentNpc, ('Converted %d %s -> %d %s.'):format(need, (tender=='cp' and 'CP' or 'Sparks'), out, rate.label))
            else
                printLine(pp, currentNpc, ('Converted %d %s -> %d %s.'):format(need, (tender=='cp' and 'CP' or 'Sparks'), u, rate.label))
            end
        end)
    end

    push('MAX', function(pp) showConfirmMax(pp, rate, pageIndex, backPage, tender) end)

    if hasNext then push('Next >>', function(pp) showUnitsPage(pp, rate, pageIndex + 1, backPage, tender) end) end

    push('<< Back', function(pp)
        if backPage == 0 then
            menu.options = rootTender
        elseif backPage == 1 then
            menu.options = page1(tender)
        elseif backPage == 2 then
            menu.options = page2(tender)
        else
            menu.options = page3(tender)
        end
        delaySendMenu(pp)
    end)

    menu.options = opts
    delaySendMenu(player)
end

-- Root pages (≤ 8 entries each) are functions of tender
page1 = function(tender)
    tender = normalizeTender(tender)
    return {
        { 'Rates & Info', function(p)
            printLine(p, currentNpc, 'Exchange Rates:')
            for _, r in ipairs(RATES) do printLine(p, currentNpc, '  ' .. formatRateLine(r, tender)) end
            printLine(p, currentNpc, 'Tip: In the quantity menu, use "MAX" to spend as much as you can afford.')
        end },
        { tender == 'cp' and 'Your CP' or 'Your Sparks', function(p)
            local amt = getPoints(p, tender)
            printLine(p, currentNpc, ('You currently have %d %s.'):format(amt, (tender=='cp' and 'CP' or 'Sparks')))
            menu.options = page1(tender)   -- re-open so it visibly responds
            delaySendMenu(p)
        end },

        { 'Byne Bill',      function(p) showUnitsPage(p, rateById('byne'),    1, 1, tender) end },
        { 'O. Bronzepiece', function(p) showUnitsPage(p, rateById('obronze'), 1, 1, tender) end },
        { 'T. Whiteshell',  function(p) showUnitsPage(p, rateById('twhite'),  1, 1, tender) end },
        { '100 Byne Bill',  function(p) showUnitsPage(p, rateById('100byne'), 1, 1, tender) end },
        { 'M. Silverpiece', function(p) showUnitsPage(p, rateById('msilver'), 1, 1, tender) end },
        { 'Next >>',        function(p) menu.options = page2(tender); delaySendMenu(p) end },
    }
end

page2 = function(tender)
    tender = normalizeTender(tender)
    return {
        { '<< Prev',        function(p) menu.options = page1(tender); delaySendMenu(p) end },
        { 'L. Jadeshell',   function(p) showUnitsPage(p, rateById('ljade'), 1, 2, tender) end },
        { 'Alexandrite',    function(p) showUnitsPage(p, rateById('alex'),  1, 2, tender) end },
        { 'Cruor',          function(p) showUnitsPage(p, rateById('cruor'), 1, 2, tender) end },
        { 'Heavy Metal Plate', function(p) showUnitsPage(p, rateById('hmp'),   1, 2, tender) end },
        { 'Riftdross',         function(p) showUnitsPage(p, rateById('dross'), 1, 2, tender) end },
        { 'Next >>',        function(p) menu.options = page3(tender); delaySendMenu(p) end },
    }
end

page3 = function(tender)
    tender = normalizeTender(tender)
    return {
        { '<< Prev',       function(p) menu.options = page2(tender); delaySendMenu(p) end },
        { 'Riftcinder',    function(p) showUnitsPage(p, rateById('cinder'), 1, 3, tender) end },
        { 'Nyzul Tokens',  function(p) showUnitsPage(p, rateById('nyzul'),  1, 3, tender) end },
        { 'Therion Ichor', function(p) showUnitsPage(p, rateById('ichor'),  1, 3, tender) end },
    }
end

-- First screen: choose tender (CP or Sparks)
showRootTender = function(p)
    local opts = {}
    local function push(lbl, fn) table.insert(opts, { lbl, fn }) end

    push('Spend CP', function(pp)
        menu.title   = 'Exchange (CP)'
        menu.options = page1('cp')
        delaySendMenu(pp)
    end)

    push('Spend Sparks', function(pp)
        menu.title   = 'Exchange (Sparks)'
        menu.options = page1('sp')
        delaySendMenu(pp)
    end)

    rootTender   = opts
    menu.options = rootTender
    delaySendMenu(p)
end

-- ======================
-- Spawner (handler-first; optional name fallback)
-- ======================
local spawnedForGuard = {}  -- key: "zoneId:npcId"

local GUARD_NAME_PATTERNS = {
    'Conquest Overseer',
    'Gate Guard',
}

local function nameLooksLikeGuard(name)
    if not name or name == '' then return false end
    for _, pat in ipairs(GUARD_NAME_PATTERNS) do
        if string.find(name, pat, 1, true) then return true end
    end
    return false
end

local function spawnExchangeBeside(guardNpc)
    local zone = guardNpc and guardNpc:getZone()
    if not zone or not zone.insertDynamicEntity then return end
    local key = tostring(zone:getID()) .. ':' .. tostring(guardNpc:getID())
    if spawnedForGuard[key] then return end

    zone:insertDynamicEntity({
        objtype  = xi.objType.NPC,
        name     = 'Exchange',
        look     = 2433, -- book model
        x = guardNpc:getXPos() + 1.2,
        y = guardNpc:getYPos(),
        z = guardNpc:getZPos() + 0.8,
        rotation = guardNpc:getRotPos(),
        widescan = 1,
        onTrigger = function(player, exNpc)
            currentNpc   = exNpc
            menu.title   = 'Exchange'
            showRootTender(player)
        end,
        onTrade = function(player, exNpc, trade)
            printLine(player, exNpc, 'No trades - use the menu to convert CP or Sparks.')
        end,
    })

    spawnedForGuard[key] = true
end

local function autospawnInZone(zone)
    local function consider(npc)
        -- Handler-based match (authoritative)
        if npc.onTrigger and (npc.onTrigger == xi.conquest.signetOnTrigger or npc.onTrigger == xi.conquest.overseerOnTrigger) then
            spawnExchangeBeside(npc)
            return
        end
        -- Optional: name fallback
        local name = (npc.getPacketName and npc:getPacketName()) or (npc.getName and npc:getName()) or ''
        if nameLooksLikeGuard(name) then spawnExchangeBeside(npc) end
    end

    if zone.forEachEntity then
        zone:forEachEntity(xi.objType.NPC, consider)
    elseif zone.iterateEntities then
        zone:iterateEntities(xi.objType.NPC, consider)
    end
end

-- Hook every zone's onInitialize; scan after a short delay
for zoneName, zoneTbl in pairs(xi.zones or {}) do
    if type(zoneTbl) == 'table' and zoneTbl.Zone and zoneTbl.Zone.onInitialize then
        m:addOverride(string.format('xi.zones.%s.Zone.onInitialize', zoneName), function(zone)
            super(zone)
            zone:timer(200, function(z) autospawnInZone(z) end)
        end)
    end
end

-- Optional safety net: spawn on first click if anything was missed
do
    local oldSignet   = xi.conquest.signetOnTrigger
    local oldOverseer = xi.conquest.overseerOnTrigger
    if oldSignet then
        xi.conquest.signetOnTrigger = function(player, npc, ...)
            spawnExchangeBeside(npc)
            return oldSignet(player, npc, ...)
        end
    end
    if oldOverseer then
        xi.conquest.overseerOnTrigger = function(player, npc, ...)
            spawnExchangeBeside(npc)
            return oldOverseer(player, npc, ...)
        end
    end
end

return m
